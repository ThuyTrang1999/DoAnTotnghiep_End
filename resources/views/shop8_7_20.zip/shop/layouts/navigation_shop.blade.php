<div class="category-sub-menu">
    <ul>
        <li class="has-sub"><a >Quản lý đơn hàng</a>
            <ul>
                <li><a href="{{route('shop.bill')}}">Xử lý đơn hàng</a></li>
            </ul>
        </li>
        <li class="has-sub"><a >Quản lý sản phẩm</a>
            <ul>
                <li><a href="{{route('shopProduct.listShopProduct')}}">Danh sách sản phẩm</a></li>
                <li><a href="{{route('shopProduct.them-moi-shop-product')}}">Thêm sản phẩm</a></li>
            </ul>
        </li>
        <li class="has-sub"><a>Kênh quảng cáo</a>
            <ul>
                <li><a href="{{route('shop.adver')}}">Chương trình khuyến mãi</a></li>
            </ul>
        </li>
        <li class="has-sub"><a>Quản lý shop</a>
            <ul>
                <li><a href="{{route('shop.review')}}">Đánh giá shop</a></li>
                <li><a href="{{route('shop.setting_shop')}}">Trang trí shop</a></li>
                <li><a href="{{route('shop.report')}}">Báo cáo của tôi</a></li>
                <li><a href="{{route('shop.update-user')}}">Cập nhật thông tin tài khoản</a></li>
                <li><a href="{{route('shop.update-shop')}}">Cập nhật thông tin shop</a></li>
            </ul>
        </li>
    </ul>
</div>