<footer>
    <div class="pull-right">
        Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
    </div>
    <div class="clearfix"></div>
</footer>
</div>
  </div>

  <!-- jQuery -->
  <script src="../assets/admin/vendors/jquery/dist/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="../assets/admin/vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- FastClick -->
  <script src="../assets/admin/vendors/fastclick/lib/fastclick.js"></script>
  <!-- NProgress -->
  <script src="../assets/admin/vendors/nprogress/nprogress.js"></script>
  <!-- Chart.js -->
  <script src="../assets/admin/vendors/Chart.js/dist/Chart.min.js"></script>
  <!-- jQuery Sparklines -->
  <script src="../assets/admin/vendors/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
  <!-- Flot -->
  <script src="../assets/admin/vendors/Flot/jquery.flot.js"></script>
  <script src="../assets/admin/vendors/Flot/jquery.flot.pie.js"></script>
  <script src="../assets/admin/vendors/Flot/jquery.flot.time.js"></script>
  <script src="../assets/admin/vendors/Flot/jquery.flot.stack.js"></script>
  <script src="../assets/admin/vendors/Flot/jquery.flot.resize.js"></script>
  <!-- Flot plugins -->
  <script src="../assets/admin/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
  <script src="../assets/admin/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
  <script src="../assets/admin/vendors/flot.curvedlines/curvedLines.js"></script>
  <!-- DateJS -->
  <script src="../assets/admin/vendors/DateJS/build/date.js"></script>
    <!-- NProgress -->
    <script src="../assets/admin/vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../assets/admin/vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <!-- <script src="../assets/admin/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../assets/admin/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../assets/admin/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../assets/admin/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../assets/admin/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../assets/admin/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="../assets/admin/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../assets/admin/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../assets/admin/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../assets/admin/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../assets/admin/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../assets/admin/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="../assets/admin/vendors/jszip/dist/jszip.min.js"></script>
    <script src="../assets/admin/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../assets/admin/vendors/pdfmake/build/vfs_fonts.js"></script> -->

    <!-- Custom Theme Scripts -->
    <script src="../assets/admin/build/js/custom.min.js"></script>
 

