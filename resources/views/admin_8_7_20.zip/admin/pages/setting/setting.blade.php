
@extends('admin.layouts.master')

@section('title')
    Cài đặt
@endsection

@section('main_content')
    <h1>Đây là trang setting</h1>
@endsection