
@extends('admin.layouts.master')

@section('title')
    Thông kê
@endsection

@section('main_content')
<h1>thoong ke</h1>
@endsection