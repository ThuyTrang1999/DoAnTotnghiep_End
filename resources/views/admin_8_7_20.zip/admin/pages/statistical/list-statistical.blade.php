
@extends('admin.layouts.master')

@section('title')
    Danhn sách thông kê
@endsection

@section('main_content')
<h1>Danh sach thống ke</h1>
@endsection